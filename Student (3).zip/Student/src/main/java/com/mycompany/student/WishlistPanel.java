/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.student;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

public class WishlistPanel extends javax.swing.JPanel {
    private JTextField wishInput;
    private String username; // Logged-in user

    /**
     * Creates new form WishlistPanel with DB integration
     */
    public WishlistPanel(String username) {
        this.username = username;
        initComponents();
        setupUI();
        loadWishesFromDatabase(); // load previous wishes
    }

    // Optional constructor for UI preview (no DB)
    public WishlistPanel() {
        initComponents();
        setupUI();
    }

    // Sets up scroll, layout, input field, and Add button behavior
    private void setupUI() {
        tilePanel.setLayout(new BoxLayout(tilePanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(tilePanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        jPanel1.remove(tilePanel);
        jPanel1.add(scrollPane, BorderLayout.CENTER);
        jPanel1.revalidate();
        jPanel1.repaint();

        // Input field before Add button
        wishInput = new JTextField(15);
        jPanel2.add(wishInput, jPanel2.getComponentCount() - 1);

        // Add button click listener
        addButton.addActionListener(e -> {
            WishTile wishTilePanel = new WishTile();
            int result = JOptionPane.showConfirmDialog(
                    this,
                    wishTilePanel,
                    "Add a Wish",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                String wishText = wishTilePanel.getWishTextValue();
                if (!wishText.isEmpty()) {
                    addTile(wishText);
                } else {
                    JOptionPane.showMessageDialog(this, "Wish cannot be empty!");
                }
            }
        });
    }

    // Add a tile to UI + save to DB
    private void addTile(String text) {
        JPanel singleTile = new JPanel(new BorderLayout());
        singleTile.setPreferredSize(new Dimension(Integer.MAX_VALUE, 35));
        singleTile.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        singleTile.setMinimumSize(new Dimension(0, 35));
        singleTile.setBackground(getRandomPastelColor());

        JLabel title = new JLabel(text, JLabel.LEFT);
        title.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 5));

        JButton closeBtn = new JButton("❌");
        closeBtn.setFocusable(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.addActionListener(e -> {
            tilePanel.remove(singleTile);
            tilePanel.revalidate();
            tilePanel.repaint();
            removeWishFromDatabase(text); // remove from DB
        });

        singleTile.add(title, BorderLayout.CENTER);
        singleTile.add(closeBtn, BorderLayout.EAST);

        tilePanel.add(singleTile);
        tilePanel.revalidate();
        tilePanel.repaint();

        addWishToDatabase(text); // add to DB
    }

    // Random pastel color generator
    private Color getRandomPastelColor() {
        Random rand = new Random();
        int r = 180 + rand.nextInt(75);
        int g = 180 + rand.nextInt(75);
        int b = 180 + rand.nextInt(75);
        return new Color(r, g, b);
    }

    // Insert wish into DB
    private void addWishToDatabase(String wish) {
        if (username == null) return; // safety check

        String sql = "INSERT INTO wishlist (username, wish) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, wish);
            stmt.executeUpdate();
            System.out.println("✅ Wish added to DB");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Remove wish from DB
    private void removeWishFromDatabase(String wish) {
        if (username == null) return; // safety check

        String sql = "DELETE FROM wishlist WHERE username = ? AND wish = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, wish);
            stmt.executeUpdate();
            System.out.println("❌ Wish removed from DB");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load all wishes of user from DB
    public void loadWishesFromDatabase() {
        if (username == null) return;

        String sql = "SELECT wish FROM wishlist WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String wishText = rs.getString("wish");
                addTile(wishText); // adds to UI
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        addButton = new javax.swing.JButton();
        tilePanel = new javax.swing.JPanel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));

        jPanel2.setBackground(new java.awt.Color(153, 0, 51));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Wishlist");

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addButton)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addComponent(addButton))
        );

        tilePanel.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel tilePanel;
    // End of variables declaration//GEN-END:variables
}
