/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.student;
import com.mycompany.student.AddTaskDialog;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

//import com.mycompany.student.AddTaskDialog;
/**
 *
 * @author Ichchha
 */
public class SchedulerPanel extends javax.swing.JPanel {
    private JPanel tasksContainer;
    private JPanel selectedTaskPanel = null;
    private String username;  // logged-in user
    private int selectedTaskId = -1; // track which DB row is selected

    public SchedulerPanel(String username) {
        this.username = username;   // pass from login frame
        initComponents();
        setupTaskPanel();
        jPanel.setLayout(new javax.swing.BoxLayout(jPanel, javax.swing.BoxLayout.Y_AXIS));
        jButton1.addActionListener(e -> showAddTaskDialog());
        jButton2.addActionListener(e -> deleteSelectedTask());

        loadTasksFromDatabase(); // load tasks when panel opens
    }

    private void setupTaskPanel() {
        jPanel.setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel(new GridLayout(1, 3));
        headerPanel.setBackground(new Color(255, 255, 180));
        headerPanel.setPreferredSize(new Dimension(headerPanel.getPreferredSize().width, 35));
        headerPanel.setPreferredSize(new Dimension(headerPanel.getPreferredSize().width, 35)); 
        headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        headerPanel.setMinimumSize(new Dimension(0, 35));

        JLabel timeHeader = new JLabel("Time", JLabel.CENTER);
        timeHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JLabel taskHeader = new JLabel("Task", JLabel.CENTER);
        taskHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JLabel descHeader = new JLabel("Description", JLabel.CENTER);
        descHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));

        headerPanel.add(timeHeader);
        headerPanel.add(taskHeader);
        headerPanel.add(descHeader);

        jPanel.add(headerPanel, BorderLayout.NORTH);

        tasksContainer = new JPanel();
        tasksContainer.setLayout(new BoxLayout(tasksContainer, BoxLayout.Y_AXIS));
        tasksContainer.setBackground(new Color(255, 255, 204));

        JScrollPane scrollPane = new JScrollPane(tasksContainer);
        scrollPane.setBorder(null);
        jPanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void showAddTaskDialog() {
        AddTaskDialog dialog = new AddTaskDialog((java.awt.Frame) null, true);
        dialog.setTaskAddedListener((task, desc, time) -> {
            addTaskToDatabase(task, desc, time);
            loadTasksFromDatabase();
        });
        dialog.setVisible(true);
    }

    private void addTaskToDatabase(String task, String desc, String time) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO schedules (username, schedule_time, task, subject) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, time);
            stmt.setString(3, task);
            stmt.setString(4, desc);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadTasksFromDatabase() {
        tasksContainer.removeAll();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT schedule_id, schedule_time, task, subject FROM schedules WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("schedule_id");
                String time = rs.getString("schedule_time");
                String task = rs.getString("task");
                String desc = rs.getString("subject");

                addTaskBlock(id, task, desc, time);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        tasksContainer.revalidate();
        tasksContainer.repaint();
    }

    private void addTaskBlock(int taskId, String task, String desc, String time) {
        JPanel taskPanel = new JPanel(new GridLayout(1, 3));
        taskPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        taskPanel.setBackground(new Color(255, 255, 230));
        taskPanel.setPreferredSize(new Dimension(taskPanel.getPreferredSize().width, 30)); 
        taskPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30)); // Allow stretching horizontally
        taskPanel.setMinimumSize(new Dimension(0, 30));


        JLabel timeLabel = new JLabel(time, JLabel.CENTER);
        JLabel taskLabel = new JLabel(task, JLabel.CENTER);
        JLabel descLabel = new JLabel(desc, JLabel.CENTER);

        taskPanel.add(timeLabel);
        taskPanel.add(taskLabel);
        taskPanel.add(descLabel);

        // Select task for delete
        taskPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (selectedTaskPanel != null) {
                    selectedTaskPanel.setBackground(new Color(255, 255, 230));
                }
                selectedTaskPanel = taskPanel;
                selectedTaskId = taskId;
                taskPanel.setBackground(new Color(255, 220, 150));
            }
        });

        tasksContainer.add(taskPanel);
    }

    private void deleteSelectedTask() {
        if (selectedTaskId != -1) {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "DELETE FROM schedules WHERE schedule_id = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, selectedTaskId);
                stmt.executeUpdate();
                System.out.println("Task deleted from DB.");
            } catch (SQLException e) {
                e.printStackTrace();
            }

            loadTasksFromDatabase();
            selectedTaskPanel = null;
            selectedTaskId = -1;
        } else {
            JOptionPane.showMessageDialog(this, "Please select a task to delete.");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setBackground(new java.awt.Color(255, 204, 204));

        jPanel2.setBackground(new java.awt.Color(153, 0, 51));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Scheduler");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jButton1.setText("➕");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel.setBackground(new java.awt.Color(255, 255, 204));

        jButton2.setText("❌");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 336, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2))
                    .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (selectedTaskPanel != null) {
        jPanel.remove(selectedTaskPanel);  // remove selected row
        selectedTaskPanel = null;          // clear selection
        jPanel.revalidate();
        jPanel.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a task to delete.");
        }
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
